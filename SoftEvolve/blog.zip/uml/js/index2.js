
$(".diagram").sequenceDiagram({theme: 'hand'});