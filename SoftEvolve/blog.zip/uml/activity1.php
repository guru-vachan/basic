<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Activity diagrams</title>
</head>
<body>

<h1 style="text-align:centre; margin-left:40%; ">SoftDesign</h1>
<br>
<h2 style="text-align:centre;">Your Automated Generated Activity Diagram</h2>

<pre class="activitydiagram">
<?php
session_start();

echo $_SESSION['data'];

?>
</pre>

<div style="margin-left:40%;">
Return <a style="" href="../index.html">HOME</a>
<br>
OR
<br>
Go <a href="activity.php">Back And Edit</a>
</div>



<script src="UML.js"></script>


</body>
</html>
