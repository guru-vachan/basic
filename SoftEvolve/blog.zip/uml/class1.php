<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Class diagrams</title>
</head>
<body>

<h1 style="text-align:centre; margin-left:40%; ">SoftDesign</h1>
<br>
<h2 style="text-align:centre;">Your Automated Generated Class Diagram</h2>

<pre class="classdiagram">
<?php
session_start();

echo $_SESSION['data'];

?>
</pre>

<div style="margin-left:40%;">
Return <a style="" href="../index.html">HOME</a>
<br>
OR
<br>
Go <a href="class.php">Back And Edit</a>
</div>



<script src="UML.js"></script>


</body>
</html>
