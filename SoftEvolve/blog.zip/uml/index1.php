<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Usecase diagrams</title>
</head>
<body>

<h1 style="text-align:centre; margin-left:40%; ">SoftDesign</h1>
<br>
<h2 style="text-align:centre;">Your Automated Generated Usecase Diagram</h2>

<pre class="usecasediagram">
<?php
session_start();

echo $_SESSION['data'];

?>
</pre>

<div style="margin-left:40%;">
Return <a style="" href="../index.html">HOME</a>
<br>
OR
<br>
Go <a href="index.php">Back And Edit</a>
</div>



<script src="UML.js"></script>


</body>
</html>
