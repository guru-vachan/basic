$(document).ready(function () {

  $('.nav-button').click(function(){
    
    $(this).parent().toggleClass('nav-show');
    
  });	

});