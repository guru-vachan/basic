<meta http-equiv="refresh" content="0; url=http://googiehost.com/pending.html" />
<!--DEFAULT_WELCOME_PAGE-->
