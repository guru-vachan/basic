<ul>
			<li id="search">
				<h2>Search</h2>
				<form method="get" action="">
					<fieldset>
					<input type="text" id="s" name="s" value="" />
					<input type="submit" id="x" value="Search" />
					</fieldset>
				</form>
			</li>
			<li>
				<h2>Categories</h2>
				<ul>
					<li><a href="#">Computer</a></li>
					<li><a href="#">History</a></li>
					<li><a href="#">Travelling</a></li>
					<li><a href="#">Economics</a></li>
					<li><a href="#">Comics</a></li>
					<li><a href="#">Religion</a></li>
					<li><a href="#">Commerce</a></li>
					<li><a href="#">Science</a></li>
				</ul>
			</li>
			
		</ul>