<div id="footer-wrap" style="position: relative;">
	<p id="legal">(c) OurSite. Design by Guruvachan Jain</a>.</p>
	</div>