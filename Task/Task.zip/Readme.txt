Step 1: Create a database name: "task"
step 2: import "task.sql" file from database folder

-+-+-++++++++++++++++++++++++++++++++++++++++++

*For apply any intern click "title" of that intern.

Requirements:

Xampp Server


=====================================================



More help 


Contact at : 8527136561




 